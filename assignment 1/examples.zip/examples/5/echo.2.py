#!/usr/bin/python3
# writen by andrewt@cse.unsw.edu.au as a COMP2041 example
# Python implementation of /bin/echo
import sys
print(' '.join(sys.argv[1:]))
