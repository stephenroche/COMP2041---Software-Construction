#!/usr/bin/perl -w

$answer = 42;
print "$answer\n";
