#!/usr/bin/python3

factor0 = 6
factor1 = 7
print(factor0 * factor1)
